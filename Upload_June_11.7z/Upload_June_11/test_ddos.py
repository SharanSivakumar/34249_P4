from scapy.all import Ether, IP, sendp

iface = "veth0"

eth = Ether(src="00:00:00:00:00:01", dst="00:00:00:00:00:02")
ip = IP(src="10.0.0.99", dst="10.0.0.2")
pkt = eth / ip

print("Sending 11000 packets...")
for i in range(11000):
    sendp(pkt, iface=iface, verbose=False)
    if i % 1000 == 0:
        print(f"Sent {i} packets")
print("Done.")
