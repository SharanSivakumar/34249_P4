#!/usr/bin/env python3
from scapy.all import Ether, IP, TCP, UDP, ICMP, sendp, AsyncSniffer
import time

SEND_IFACE = "veth1"
RECV_IFACE = "veth3"
SLEEP_TIME = 0.5

test_results = []

def report(pkt_sent, pkt_received, description, expected_result):
    print(f"\n=== {description} ===")
    print("Packet sent:")
    pkt_sent.show2()
    print("Packet received:")

    if pkt_received:
        pkt_received.show2()
        result = "PASS" if expected_result == "receive" else "FAIL"
    else:
        print("No packet received.")
        result = "PASS" if expected_result == "drop" else "FAIL"

    print(f"[{result}]")
    test_results.append((description, result))

def run_test(pkt, description, expected_result):
    sniffer = AsyncSniffer(
        iface=RECV_IFACE,
        count=1,
        timeout=2,
        store=True
    )
    sniffer.start()
    sendp(pkt, iface=SEND_IFACE, verbose=False)
    sniffer.join()
    time.sleep(SLEEP_TIME)

    pkts = sniffer.results
    pkt_recv = pkts[0] if pkts else None
    report(pkt, pkt_recv, description, expected_result)

def print_summary():
    print("\n===== TEST SUMMARY =====")
    for desc, result in test_results:
        print(f"{desc}: {result}")
    print("========================")

def main():
    allowed_ip = "10.0.0.1"
    blacklisted_ip = "10.0.0.66"
    allowed_port = 80
    disallowed_port = 1234
    dst_ip = "10.0.0.2"

    # Under threshold (should pass)
    for i in range(3):
        pkt = Ether() / IP(src=allowed_ip, dst=dst_ip) / TCP(sport=1000+i, dport=allowed_port)
        run_test(pkt, f"Test 1.{i+1}: Allowed TCP under threshold", expected_result="receive")

    # Exceeding threshold (should get dropped after 5th)
    for i in range(5):
        pkt = Ether() / IP(src=allowed_ip, dst=dst_ip) / TCP(sport=2000+i, dport=allowed_port)
        drop_expected = i >= 2  # After 5 total packets
        run_test(pkt, f"Test 2.{i+1}: TCP exceeding threshold", expected_result="drop" if drop_expected else "receive")

    # Disallowed port
    pkt = Ether() / IP(src="10.0.0.2", dst=dst_ip) / TCP(sport=4444, dport=disallowed_port)
    run_test(pkt, "Test 3: TCP to disallowed port", expected_result="drop")

    # Blacklisted IP
    pkt = Ether() / IP(src=blacklisted_ip, dst=dst_ip) / TCP(sport=5555, dport=allowed_port)
    run_test(pkt, "Test 4: TCP from blacklisted IP", expected_result="drop")

    # ICMP
    pkt = Ether() / IP(src="10.0.0.3", dst=dst_ip) / ICMP()
    run_test(pkt, "Test 5: ICMP packet (non-TCP)", expected_result="receive")

    # UDP
    pkt = Ether() / IP(src="10.0.0.4", dst=dst_ip) / UDP(sport=8888, dport=allowed_port)
    run_test(pkt, "Test 6: UDP packet (non-TCP)", expected_result="receive")

    print_summary()

if __name__ == "__main__":
    main()
